# Profile Card - LocalStorage - (Signup Example)

A Pen created on CodePen.

Original URL: [https://codepen.io/danilo-san-felipe-rosco/pen/Wbxvrgj](https://codepen.io/danilo-san-felipe-rosco/pen/Wbxvrgj).

